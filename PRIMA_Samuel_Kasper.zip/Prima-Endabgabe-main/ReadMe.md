Link zur Anwendung: https://samuelkasper.github.io/Prima-Endabgabe/EndabgabeCode/index.html

Link zum Code: https://github.com/SamuelKasper/Prima-Endabgabe/tree/main/EndabgabeCode

Link zum Designdokument: https://github.com/SamuelKasper/Prima-Endabgabe/blob/main/Designdokument/Designdokument.pdf